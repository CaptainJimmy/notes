var express = require("express");
var mysql = require("mysql");

var app = express();
var PORT = process.env.PORT || 3000;

var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "seinfeld",
  port: 8889
});

// Initiate MySQL Connection.
connection.connect(function(err) {
  if (err) {
    console.error("error connecting: " + err.stack);
    return;
  }
  console.log("connected as id " + connection.threadId);
});


app.get("/cast", function(req,res) {
  connection.query("SELECT * FROM actors", function(err, result) {
    if (err) throw err;

     // We then begin building out HTML elements for the page.
     var html = "<h1> What's the deal with this cast. </h1>";
     
         // Here we begin an unordered list.
         html += "<ul>";
     
         // We then use the retrieved records from the database to populate our HTML file.
         for (var i = 0; i < result.length; i++) {
           html += "<li><p> ID: " + result[i].id + "</p>";
           html += "<p>School: " + result[i].name + " </p>";
           html += "<p> Coolness Points: " + result[i].coolness_points + "</p>";
           html += "<p> Attitude: " + result[i].attitude + "</p></li>"
         }
     
         // We close our unordered list.
         html += "</ul>";
     
         // Finally we send the user the HTML file we dynamically created.
         res.send(html);
  });
});

app.get("/coolness-chart", function(req,res) {
  connection.query("SELECT * FROM actors ORDER BY coolness_points DESC", function(err, result) {
    if (err) throw err;

     // We then begin building out HTML elements for the page.
     var html = "<h1> What's the deal with this cast. </h1>";
     
         // Here we begin an unordered list.
         html += "<ul>";
     
         // We then use the retrieved records from the database to populate our HTML file.
         for (var i = 0; i < result.length; i++) {
           html += "<li><p> ID: " + result[i].id + "</p>";
           html += "<p>School: " + result[i].name + " </p>";
           html += "<p> Coolness Points: " + result[i].coolness_points + "</p>";
           html += "<p> Attitude: " + result[i].attitude + "</p></li>"
         }
     
         // We close our unordered list.
         html += "</ul>";
     
         // Finally we send the user the HTML file we dynamically created.
         res.send(html);
  });
});

app.get("/attitude-chart/:att", function(req,res) {

  var attitude = req.params.att;

  connection.query("SELECT * FROM actors WHERE ?", 
  {
    attitude: attitude
  },
  function(err, result) {
    if (err) throw err;

     // We then begin building out HTML elements for the page.
     var html = "<h1> What's the deal with this cast. </h1>";
     
         // Here we begin an unordered list.
         html += "<ul>";
     
         // We then use the retrieved records from the database to populate our HTML file.
         for (var i = 0; i < result.length; i++) {
           html += "<li><p> ID: " + result[i].id + "</p>";
           html += "<p>School: " + result[i].name + " </p>";
           html += "<p> Coolness Points: " + result[i].coolness_points + "</p>";
           html += "<p> Attitude: " + result[i].attitude + "</p></li>"
         }
     
         // We close our unordered list.
         html += "</ul>";
     
         // Finally we send the user the HTML file we dynamically created.
         res.send(html);
  });
});








app.listen(PORT, function() {
  console.log("It's working!");
})