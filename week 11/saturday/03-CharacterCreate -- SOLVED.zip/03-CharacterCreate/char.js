
function Character(name, profession, gender, age, strength, hitpoints) {
  this.name = name;
  this.profession = profession;
  this.gender = gender;
  this.age = age;
  this.strength = strength;
  this.hitpoints = hitpoints;

  this.printStats = function() {
    console.log("\n==================\n");
    console.log("Name: " + this.name);
    console.log("Profession: " + this.profession);
    console.log("Gender: " + this.gender);
    console.log("Age: " + this.age);
    console.log("Strength: " + this.strength);
    console.log("Hit Points (HP): " + this.hitpoints);
    console.log("\n==================\n"); 
  }

  this.isAlive = function() {
    if (this.hitpoints > 0) {
      console.log("\n============");
      console.log(this.name + " is still alive!");
      console.log("\n============");     
      return true; 
    } else {
      console.log("\n============");
      console.log(this.name + " is dead!");
      console.log("\n============");   
      return false;   
    }
  }

  this.attack = function(enemy) {
    var newHitpoints = enemy.hitpoints - this.strength;
    enemy.hitpoints = newHitpoints;
    console.log("Your " + enemy.name + " now has " + enemy.hitpoints + " health.");

  }

  this.levelUp = function() {
    this.age += 1;
    this.strength += 5;
    this.hitpoints += 25;
  }
}

var will = new Character("Guy Fawkes", "Pyrotechnician", "Male", 447, 87, 500);

var steve = new Character("Steve Jobs' Ghost", "Ghost Genius", "Male", 62, 145, 300);

will.printStats();
steve.printStats();

will.attack(steve);
steve.printStats();
steve.isAlive();

will.levelUp();
will.printStats();


while (steve.isAlive() === true && will.isAlive() === true) {
  steve.attack(will);
  will.attack(steve);

  steve.printStats();
  will.printStats();
}